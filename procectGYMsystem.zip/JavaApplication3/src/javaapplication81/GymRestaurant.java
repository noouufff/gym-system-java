/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class GymRestaurant implements GymPayingSystem {

    private String mealName;
    private static int Mealprice;

    public GymRestaurant(String mealName) {
        this.mealName = mealName;
    }

    public GymRestaurant() {
        this("");
    }

    @Override
    public void giveMeal(double weight) {
        if (weight >= 100) {
            System.out.println("Giving " + mealName + " to the member.");
        } else {
            System.out.println("Meal is not available for members under 100kg.");
        }
    }

    @Override
    public String toString() {
        return "GymRestaurant{" + "mealName=" + mealName + '}';
    }

    

    public static int getMealprice() {
        return Mealprice;
    }

    public static void setMealprice(int Mealprice) {
        GymRestaurant.Mealprice = Mealprice;
    }

    public String getMealName() {
        return mealName;
    }

    public void setMealName(String mealName) {
        this.mealName = mealName;
    }

    public static double Discount(double weight) {
        if (weight > 50) {
            return Mealprice * 0.15;
        } else {
            return Mealprice;
        }
    }

}