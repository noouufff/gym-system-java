/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public final class Date {

    private int year;
    private int month;
    private int day;

  // Constructors
    public Date(int year, int month, int day) {
        setYear(year);
        setMonth(month);
        setDay(day);

    }

    public Date() {
        this(0, 0, 0);
    }

    //setters & getters
    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year < 2024) {
            System.out.println("invalid year");
        } else {
            this.year = year;
        }
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        if (month < 1 || month > 12) {
            System.out.println("invalid month");
        } else {
            this.month = month;
        }
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        if (day < 1 || day > 31) {
            System.out.println("Invalid day enter again");
        } else {
            this.day = day;
        }
    }

    @Override
    public String toString() {
        return String.format("%d/%d/%d", getYear(), getMonth(), getDay());
    }
}