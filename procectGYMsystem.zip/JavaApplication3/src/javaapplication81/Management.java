/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class Management extends person {

        private String department;
        private static int NumOfEmployee;

        public Management(String department, String name, User user) {
            super(name, user);
            this.department = department;
            NumOfEmployee++;
            System.out.println("The number of Employees: " + NumOfEmployee);
        }

        public Management() {
            this("", "", null);
        }

        public String getDepartment() {
            return department;
        }

        public void setDepartment(String department) {
            this.department = department;
        }

        @Override
        public String toString() {
            return "Management{" + "department=" + department + '}';
        }

        public static int getNumOfEmployee() {
            return NumOfEmployee;
        }

  
}