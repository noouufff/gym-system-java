/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class ThreeMonths extends Membership {

    public ThreeMonths(Date date, Booking booking, String MembershipId, Advantages[] advantages, String startingDate, String endingDate, double price, boolean isSick, int age) {
        super(date, booking, MembershipId, advantages, startingDate, endingDate, price, isSick, age);
    }

    

    public ThreeMonths() {
    }


        

       

        @Override
        public void giveMeal(double weight) {
            System.out.println("you have 3 free Meals..");
        }
    
    
}
