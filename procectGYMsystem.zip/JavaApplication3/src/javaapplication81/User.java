/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class User {

        private String email;
        private int number;
        private String address;

        public User(String email, int number, String address) {
            this.email = email;
            this.number = number;
            this.address = address;
        }

        public User() {
            this("", 0, "");

        }

        @Override
        public String toString() {
            return "User{" + "email=" + email + ", number=" + number + ", address=" + address + '}';
        }

    

}
