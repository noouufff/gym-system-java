/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class Coach extends person {

        private String speciality;

        public Coach(String speciality, String name, User user) {
            super(name, user);
            this.speciality = speciality;
        }
        public Coach(){
            this("","",null);
        }

        public Coach(String speciality) {
            this.speciality = speciality;
        }

        public void setSpeciality(String speciality) {
            this.speciality = speciality;
        }

        public String getSpeciality() {
            return speciality;
        }
   
}