/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class Advantages {

    private String benefitId;
    private String name;
    private String description;

    //constructors
    public Advantages(String benefitId, String name, String description) {
        setBenefitId(benefitId);
        setName(name);
        setDescription(description);

    }

    public Advantages() {
        this("", "", "");
    }

    //setters & getters
    public String getBenefitId() {
        return benefitId;
    }

    public void setBenefitId(String benefitId) {
        this.benefitId = benefitId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return String.format("Benefit Id: %s\nBenefit name: %s\nDescription: %s\n", getBenefitId(), getName(), getDescription());
    }

}
