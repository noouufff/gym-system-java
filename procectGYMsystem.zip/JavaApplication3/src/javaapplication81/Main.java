/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    static ArrayList<GymPayingSystem> list = new ArrayList<>();
    static ArrayList<Membership> listt = new ArrayList<>();
    static ArrayList<Booking> list3 = new ArrayList<>();

    public static void fillList() {

        // public Advantages(String benefitId, String name, String description) {
        Yoga Y = new Yoga();
        Advantages[] Advantages1 = new Advantages[2];
        Advantages1[0] = new Advantages("1", "Access to Premium Equipment", "Equipment");
        Advantages1[1] = new Advantages("2", "Personalized Training Sessions", "Training");
        OneMonth one = new OneMonth(null, null, "101", Advantages1, "", "", 12.0, true, 7);
// OneMonth(Date date, Booking booking, String MembershipId, Advantages[] advantages, String startingDate, String endingDate, double price, boolean isSick, int age) {
        //public OneMonth(Advantages[] advantages, SportsLectures sportlec, String startingDate, String endingDate, double price, boolean isSick, int age) {

        Advantages[] Advantages2 = new Advantages[2];
        Advantages2[0] = new Advantages("1", "Access to Premium Equipment", "Equipment");
        Advantages2[1] = new Advantages("2", "Personalized Training Sessions", "Training");
        OneMonth one1 = new OneMonth(null, null, "102", Advantages2, "", "", 12.0, true, 7);

        Advantages[] Advantages3 = new Advantages[2];
        Advantages3[0] = new Advantages("1", "Access to Premium Equipment", "Equipment");
        Advantages3[1] = new Advantages("2", "Personalized Training Sessions", "Training");
        ThreeMonths three = new ThreeMonths(null, null, "103", Advantages3, "", "", 12.0, true, 7);

        Advantages[] Advantages4 = new Advantages[2];
        Advantages4[0] = new Advantages("1", "Access to Premium Equipment", "Equipment");
        Advantages4[1] = new Advantages("2", "Personalized Training Sessions", "Training");
        //ThreeMonths three1 = new ThreeMonths(Advantages4,null   ,"", "", 12.0,true,7);
        ThreeMonths three1 = new ThreeMonths(null, null, "4", Advantages4, "", "", 12.0, true, 7);

        //User(String email, int number, String address)
        //Coach(String speciality, String name, User user)
        //Coach coach = new Coach("", "",new User("",0,"") );
        //(Advantages[] advantages, SportsLectures sportlec, String startingDate, String endingDate, double price, boolean isSick, int age
        Advantages[] Advantages5 = new Advantages[2];
        Advantages5[0] = new Advantages("1", "Access to Premium Equipment", "Equipment");
        Advantages5[1] = new Advantages("2", "Personalized Training Sessions", "Training");
        SixMonths six = new SixMonths("free pool training", null, null, "2", Advantages5, "", "", 12.0, true, 7);
//    public SixMonths(String freePoolTraining, Date date, Booking booking, String MembershipId, Advantages[] advantages, String startingDate, String endingDate, double price, boolean isSick, int age) {

        Advantages[] Advantages6 = new Advantages[2];
        Advantages6[0] = new Advantages("1", "Access to Premium Equipment", "Equipment");
        Advantages6[1] = new Advantages("2", "Personalized Training Sessions", "Training");
        SixMonths six1 = new SixMonths("free pool training", null, null, "1", Advantages6, "", "", 12.0, true, 7);

        listt.add(one);
        listt.add(one1);
        listt.add(three);
        listt.add(three1);
        listt.add(six);
        listt.add(six1);

    }

    public static void menu() {
        System.out.print("\n1. Add Membership.\n"
                + "2. Remove Membership.\n"
                + "3. Display Membership.\n"
                + "4. New booking.\n"
                + "5. Show Membership.\n"
                + "6. Cancel Membership.\n"
                + "7. Order from gym restuarant \n"//how many booking u want(call the method that compares max)
                + "8. GUI.\n"
                + "9. Read From File.\n"
                + "10.Save Orders.\n" + "11.Exit.\n"
                + ">> ");
    }

    public static void main(String[] args) {
        // TODO code application logic here

        //Membership membership=new Membership("2/2/2024","10/2/2024",1000.50,false,"chicken",2) ;
        Scanner input = new Scanner(System.in);

        //SportsLectures sportlec, String startingDate, String endingDate, double price, boolean isSick, int age
        int choice = 0;
        fillList();
        System.out.println(" WELCOME TO THE GYM SYSTEM ");
        do {
            try {
                menu();
                choice = input.nextInt();
                switch (choice) {

                    case 1://Add Subscription
                        System.out.print("1. one month Membership\n"
                                + "2. three month Membership\n"
                                + "3. six month Membership\n"
                                + "Select type of the Membership to add >> ");
                        int MembershipType = input.nextInt();

                        if (MembershipType < 1 || MembershipType > 6) {
                            System.out.println("Invalid choice.");
                        } else {

                            Membership subscription = null;
                            //System.out.print("Enter subscription starting date: ");
                            // String subscriptionStartingDate = input.next();
                            input.nextLine();
                            //System.out.print("Enter subscription ending date: ");
                            //String subscriptionEndingDate = input.next();
                            System.out.print("Enter price per month:");
                            double pricePerMonth = input.nextDouble();
                            System.out.print("are you sick?  ");
                            boolean sick = input.nextBoolean();
                            System.out.print("whats youre age? ");
                            int age = input.nextInt();
                            System.out.print("whats youre ID? ");
                            int id = input.nextInt();
                            //  Membership m1 = new Membership(null,null, "", null, null, "", "", 0,false,0);
//        public SixMonths(Date date, Booking booking, String MembershipId, Advantages[] advantages, SportsLectures sportlec, String startingDate, String endingDate, double price, boolean isSick, int age) {

                            System.out.print("How many Advantages you want added? ");

                            int numberAdvantages = input.nextInt();
                            //add array composition
                            Advantages[] adv = new Advantages[numberAdvantages];

                            // Benefit(String benefitId, String description)
                            for (int i = 0; i < adv.length; i++) {
                                input.nextLine();
                                System.out.print("Enter Advantage id: ");
                                String advid = input.next();
                                System.out.println("Enter Advantage name: ");
                                String benefitName = input.next();
                                input.nextLine();
                                System.out.print("Enter description: ");
                                String description = input.nextLine();
                                adv[i] = new Advantages(advid, benefitName, description);

                            }

                            // System.out.print("Enter duration in month: ");
                            //int durationInMonth = input.nextInt();
                            //if or switch
                            switch (MembershipType) {
                                case 1:
                                    System.out.print("Enter max GYM accesstimes: ");
                                    int maxAcc = input.nextInt();

                                    //    public OneMonth(Advantages[] advantages, SportsLectures sportlec, String startingDate, String endingDate, double price, boolean isSick, int age) {
                                    OneMonth onemonth = new OneMonth();

                                    list.add(onemonth);
                                    onemonth.giveMeal(0);

                                    break;
                                case 2:
                                    //System.out.print("Enter additional perks: ");
                                    //String additionalPerks = input.nextLine();
                                    //ThreeMonths threemonth = new ThreeMonths(null,null, "", null, null, "", "", 0,false,0);
                                    ThreeMonths threemonth = new ThreeMonths();
                                    list.add(threemonth);
                                    threemonth.giveMeal(0);

                                    break;

                                case 3:
                                    //System.out.print("Enter additional perks: ");
                                    //String additionalPerks = input.nextLine();

                                    // SixMonths sixmonth = new SixMonths("",null, "", "", 44, false, 9);
                                    SixMonths six = new SixMonths();

                                    // list.add(sixmonth);
                                    list.add(six);
                                    six.giveMeal(0);

                                    break;

                                default:

                                    System.out.print("Enter coach name: ");
                                    String coachName = input.nextLine();
                                    System.out.println("Enter coach mainSpecialization: ");
                                    String mainSpecialization = input.nextLine();
                                    System.out.println("Enter coach email: ");
                                    String coachemail = input.nextLine();
                                    System.out.println("Enter coach number: ");
                                    int coachnum = input.nextInt();
                                    System.out.println("Enter coach adress: ");
                                    String coachadress = input.nextLine();
                                    Coach coach1 = new Coach(mainSpecialization, coachName, new User(coachemail, coachnum, coachadress));

                                    break;
                            }
                            list.add(subscription);
                            System.out.println("membership has been added to the list.");

                        }//end else
                        break;

                    case 2:
//Remove subscription

//Remove subscription
                        System.out.print("Enter membership id to remove: ");
                        String membId = input.next();
                        boolean removed = false;
                        for (int i = 0; i < listt.size(); i++) {
                            Membership ele = listt.get(i);
                            if (ele.getMembershipId().equals(membId)) {
                                listt.remove(i);
                                removed = true;
                                break;
                            }
                        }//end loop
                        if (removed) {
                            System.out.println("Membership with id " + membId + " is deletd");
                        } else {
                            System.out.println("No Membership with id " + membId + " exist");
                        }
                        break;
                    case 3://Display member
                        //done
                        for (GymPayingSystem ele : list) {
                            // Polymorphic methods(Polymorphism)
                            System.out.println(ele);
                            System.out.printf("Membership meal: %n");
                            ele.giveMeal(0);

                            // Downcasting to call specific methods 
                            System.out.println("----------------------------");
                            if (ele instanceof SixMonths) {
                                System.out.println(((SixMonths) ele).getFreePoolTraining());//add an instance in 6 months class or mathod and call it here
                            }
                            System.out.println("----------------------------");
                        }
                        break;

                    case 4://New Registration
                        System.out.printf("Enter membership  id: ");
                        membId = input.next();
                        //search for Subscription

                        Membership sub = null;
                        boolean isFound = false;

                        for (Membership ele : listt) {
                            //ele.getMembershipId().equals(membId)
                            if (ele.getMembershipId().equals(membId)) {
                                sub = ele;
                                isFound = true;
                                break;
                            }
                        }
                        if (!isFound) {
                            System.out.println("Invalid membership id");
                            continue;
                        }
                        //end while loop

                        System.out.println("Enter membership starting date:");
                        System.out.print("year: ");
                        int year = input.nextInt();
                        if (year < 2024) {
                            System.out.println("Invalid year.");
                            continue;
                        }
                        System.out.print("month: ");
                        int month = input.nextInt();
                        if (month < 1 || month > 12) {
                            System.out.println("Invalid month.");
                            continue;
                        }
                        System.out.print("day: ");
                        int day = input.nextInt();

                        if (day < 1 || day > 31) {
                            System.out.println("Invalid day.");
                            continue;
                        }
                        Date date1 = new Date(year, month, day);

//==get member information==
                        System.out.print("Enter your email: ");
                        String email = input.next();
                        input.nextLine();
                        System.out.print("Enter your adress: ");
                        String adress = input.nextLine();
                        System.out.print("Enter phone number: ");
                        int phoneNo = input.nextInt();

                        System.out.print("Enter youre name: ");
                        String name = input.next();
                        User user1 = new User(email, phoneNo, adress);
                        Member member1 = new Member(name, user1);

                        //User u= new User ("coach1@gmail.com",111222,"");
                        // Coach ca =new Coach("yoga coach","sara",u);
                        Coach C = new Coach();
                        Booking b = new Booking(1, C, member1, 15);
                        list3.add(b);
                        //Registration registration = new Registration(sub, date, trainee);
                        System.out.print("how many bookings do u want? ");
                        int answer = input.nextInt();
                        b.setMaxBooking(answer);

                        System.out.print("do u want to remove booking? (Yes/No): ");
                        String answer2 = input.next();
                        if (answer2.equals("yes") || answer2.equals("Yes")) {
                            b.cancelBooking();
                            list3.remove(b);
                            b.toString();
                        } else {
                            System.out.println("Your booking has been Coniformed");
                        }

                        break;

                    case 5://Show member
                        System.out.print("Enter MemberNumber : ");
                        int memnum = input.nextInt();
                        boolean found = false;
                        for (Membership ele : listt) {
                            if (ele.getMembershipId().equals(memnum)) {
                                System.out.println(ele);
                                found = true;
                            }
                        }//end loop
                        if (found == false) {
                            System.out.println("MemberNumber : " + memnum + " is not found");
                        }
                        break;

                    case 6://Cancel registration
                        System.out.print("Enter booking id: ");
                        int bookingnum = input.nextInt();
                        found = false;
                        for (Booking ele : list3) {
                            if (ele.getBookingnum() == bookingnum) {
                                ele.cancelBooking();
                                System.out.println(ele);
                                found = true;
                            }
                        }
                        if (found == false) {
                            System.out.println("booking with number " + bookingnum + " is not found");
                        }
                        break;

                    case 7:
                        ArrayList<GymRestaurant> GymRestaurant = new ArrayList<>();
                        GymRestaurant.add(new GymRestaurant("amlond power shake"));
                        GymRestaurant.add(new GymRestaurant("pasta"));
                        GymRestaurant.add(new GymRestaurant("crab salad"));
                        GymRestaurant.add(new GymRestaurant("sugar-free coffee"));

                        for (int i = 0; i < GymRestaurant.size(); i++) {
                            System.out.println(i + "-" + GymRestaurant.get(i));
                            System.out.println("----------------");
                        }
                        System.out.print("Enter the item index:");
                        int index = input.nextInt();
                        if (index < 0 || index >= GymRestaurant.size()) {
                            System.out.println("invalid index");
                            continue;
                        }

                        GymRestaurant item = GymRestaurant.get(index);

                        System.out.println(item);

                        System.out.println("Thanks for youre order.");

                        break;

                    case 8://GUI
                        GYMGUI.main(null);
                        //calling static method
                        //GymMembershipApp.Main(null);
                        break;

                    case 9://Read from text file
                        ReadText rt = new ReadText();
                        rt.openTextFile("membership.txt");
                        rt.readFromFile();
                        rt.closeFile();
                        break;

                    case 10://Save/Write to text file
                        WriteText wf = new WriteText();
                        wf.openTextFile("membership.txt");
                        if (listt.isEmpty()) {
                            System.out.println("No orders yet.");
                        } else {
                            for (Membership ele : listt) {
                                wf.writeToFile(ele);
                            }
                        }
                        wf.closeFile();
                        System.out.println("All orders saved to the text file orders.txt");
                        break;

                    case 11://Exit
                        System.out.println("Thank you for using our system.\nHave a nice day.");
                        break;
                    default:
                        System.out.println("Invalid Choice!");
                }
            } catch (InputMismatchException ex) {
                System.err.println("Invalid input");
                input.nextLine();
            } catch (NullPointerException ex) {
                System.err.println(ex);
            } catch (ClassCastException ex) {
                System.err.println(ex);
            } catch (ArrayIndexOutOfBoundsException ex) {
                System.err.println(ex);
            } catch (Exception ex) {
                System.err.println(ex);
            }
        } while (choice != 11);

    }

}
