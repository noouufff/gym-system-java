/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */


public class Cardio  extends SportsLecturs{
    

        final String SPORT_NAME = "cardio";

        @Override
        public String toString() {
            return "Cardio{" + "SPORT_NAME=" + SPORT_NAME + '}';
        }

        @Override
        public void wayOfThisSport() {
            System.out.println("Cardio starts with a warmup and body movements, short for cardiovascular exercise, referring to activities that elevate your heart rate.");
        }
    }