/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class Membership implements GymPayingSystem {

    private Date date;
    private Booking booking;
    private String MembershipId;
    private Advantages[] advantages;
    protected String startingDate;
    protected String endingDate;
    private double price;
    private final double TAX = 0.15;
    private boolean isSick;
    private int age;

    public Membership(Date date, Booking booking, String MembershipId, Advantages[] advantages, String startingDate, String endingDate, double price, boolean isSick, int age) {
        this.date = date;
        this.booking = booking;
        this.MembershipId = MembershipId;
        this.advantages = advantages;
        this.startingDate = startingDate;
        this.endingDate = endingDate;
        this.price = price;
        this.isSick = isSick;
        this.age = age;
    }

    @Override
    public void giveMeal(double weight) {

    }

    public Membership() {
        this(null, null, "", null, "", "", 0, false, 0);

    }

    public String getMembershipId() {
        return MembershipId;
    }

    public void setMembershipId(String MembershipId) {
        this.MembershipId = MembershipId;
    }

    public Advantages[] getAdvantages() {
        return advantages;
    }

    public void setAdvantages(Advantages[] advantages) {
        this.advantages = advantages;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void isSick() {
        if (isSick) {
            System.out.println("You're not allowed to enter; you should go back to the gym doctor.");
        } else {
            System.out.println("Welcome to our gym.");
        }
    }

    public double PriceIncludingTax() {
        if (age > 7 || age < 16) {

            return price * TAX;
        } else if (age > 16 || age < 100) {
            return price * TAX;
        } else {
            return 0;
        }

    }

    public String getStartingDate() {
        return startingDate;
    }

    public void setStartingDate(String startingDate) {
        this.startingDate = startingDate;
    }

    public String getEndingDate() {
        return endingDate;
    }

    public void setEndingDate(String endingDate) {
        this.endingDate = endingDate;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isIsSick() {
        return isSick;
    }

    public void setIsSick(boolean isSick) {
        this.isSick = isSick;
    }

    public final String getAdvantage() {

        String b = " ";
        if (advantages == null) {
            b = " ";
        } else {

            for (int i = 0; i < advantages.length; i++) {
                b += advantages[i] + "\n------------------------\n";
            }
        }

        return b;

    }

    @Override
    public String toString() {
        return "Membership{" + "date=" + date + ", booking=" + booking + ", MembershipId= " + MembershipId + ", advantages=" + getAdvantage() + ", startingDate=" + startingDate + ", endingDate=" + endingDate + ", price=" + price + ", TAX=" + TAX + ", isSick=" + isSick + ", age=" + age + '}';
    }

}
