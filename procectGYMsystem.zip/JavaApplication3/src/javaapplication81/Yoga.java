/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class Yoga extends SportsLecturs {
    
        final String SPORT_NAME = "yoga";

        public Yoga() {
        }

        @Override
        public String toString() {
            return "Yoga{" + "SPORT_NAME=" + SPORT_NAME + '}';
        }

        @Override
       public void wayOfThisSport() {
            System.out.println("Yoga can be practiced by meditation and breathing techniques.");
        }
    }