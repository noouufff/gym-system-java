/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */

public class pilaties extends SportsLecturs {
    
        final String SPORT_NAME = "pilates";

        @Override
        public String toString() {
            return "Pilates{" + "SPORT_NAME=" + SPORT_NAME + '}';
        }

        @Override
        public void wayOfThisSport() {
            System.out.println("Pilates works by focusing on equalizing body sides of the body and balancing motion and strength.");
        }
    
}
