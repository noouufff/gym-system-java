/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class SixMonths extends Membership {

        private String freePoolTraining;

    public SixMonths(String freePoolTraining, Date date, Booking booking, String MembershipId, Advantages[] advantages, String startingDate, String endingDate, double price, boolean isSick, int age) {
        super(date, booking, MembershipId, advantages, startingDate, endingDate, price, isSick, age);
        this.freePoolTraining = freePoolTraining;
    }

    

    public SixMonths(String freePoolTraining) {
        this.freePoolTraining = freePoolTraining;
    }
    public SixMonths(){
        
    }



    
        @Override
        public void giveMeal(double weight) {
            System.out.println("you have 6 free Meals..");
        }

        public String getFreePoolTraining() {
            System.out.println("you have free pool training");
            return freePoolTraining;
        }

        public void setFreePoolTraining(String freePoolTraining) {
            this.freePoolTraining = freePoolTraining;
        }

        
        
        
    
}