/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;

/**
 *
 * @author razan
 */
public class Booking {
    
        private int Bookingnum;
        private Coach coach;
        private Member member;
        private int maxBooking;
        private static int bookingPerDay;

        public Booking(int Bookingnum, Coach coach, Member member, int maxBooking) {
            this.Bookingnum = Bookingnum;
            this.coach = coach;
            this.member = member;
            this.maxBooking = maxBooking;
                        bookingPerDay++;

        }

        public int getBookingnum() {
            return Bookingnum;
        }

        public void setBookingnum(int Bookingnum) {
            this.Bookingnum = Bookingnum;
        }

        

        
        public Booking() {
            this( 0,null, null, 0);
        }

        public void MaxBooking() {
            if (bookingPerDay > maxBooking) {
                System.out.println("Sorry there is no Available rooms");
            }

        }

        public final void cancelBooking(){
                                    bookingPerDay--;
            System.out.println("booking is canceled");
            
        }
        
        public int getMaxBooking() {
            return maxBooking;
        }

        public void setMaxBooking(int maxBooking) {
            this.maxBooking = maxBooking;
        }

        public int getBookingPerDay() {
            return bookingPerDay;
        }

        public void setBookingPerDay(int bookingPerDay) {
            this.bookingPerDay = bookingPerDay;
        }

       

        public Coach getCoach() {
            return coach;
        }

        public void setCoach(Coach coach) {
            this.coach = coach;
        }

        public Member getMember() {
            return member;
        }

        public void setMember(Member member) {
            this.member = member;
        }

        @Override
        public String toString() {
            return "Booking{" + "coach=" + coach + ", member=" + member + ", maxBooking=" + maxBooking + '}';
        }

    

      
    }