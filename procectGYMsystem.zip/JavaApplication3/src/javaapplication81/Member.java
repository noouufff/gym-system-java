/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication81;


public class Member extends person  {

        private static int memberCounter = 0;

        public Member(String name, User user) {
            super(name, user);
            memberCounter++;
            System.out.println("The number of members: " + memberCounter);
        }

        
        
        public Member() {

            this("", null);
        }

        public static int getMemberCounter() {
            return memberCounter;
        }

        public void Rating() {
            if (memberCounter > 100) {
                System.out.println("The rating is 4.5");
            } else {
                System.out.println("The rating is below 4.5");
            }
        }
    }